create schema videogiochi;

-- Creazione tabella Store.
CREATE TABLE STORE (
    Codicestore INTEGER NOT NULL,
    IndirizzoFisico VARCHAR(255),
    NumeroTelefono VARCHAR(255)
);

-- Creazione tabella impiegato.
CREATE TABLE IMPIEGATO (
    CodiceFiscale VARCHAR(16) NOT NULL UNIQUE,
    Nome INTEGER NOT NULL,
    TitoloStudio VARCHAR(255),
    Recapito VARCHAR(255) NOT NULL
);

-- Creazione tabella Servizio impiegato.
CREATE TABLE SERVIZIO_IMPIEGATO (
    CodiceFiscale VARCHAR(16) NOT NULL UNIQUE,
    CodiceStore INTEGER NOT NULL,
    DataInizio DATE NOT NULL,
    DataFine DATE NOT NULL,
    Carica VARCHAR(255) NOT NULL
);

-- Creazione tabella Videogioco.
CREATE TABLE VIDEOGIOCO (
    Titolo VARCHAR(255) NOT NULL,
    Sviluppatore VARCHAR(255) NOT NULL,
    AnnoDistribuzione DATE NOT NULL,
    CostoAcquisto FLOAT NOT NULL,
    Genere VARCHAR(255)
);

-- creazione tabella disposizione videogioco
Create table disposizione_videogioco
(
ID_disp int not null auto_increment primary key,
titolo varchar(50) not null,
codicestore int not null,
settore int,
num_copie int,
foreign key (titolo) references videogioco(titolo),
foreign key (codicestore) references store(codicestore)
);

-- prova tabella
select * from disposizione_videogioco;
select * from disposizione_videogioco;

-- cancellazione tabella
drop table disposizione_videogioco;

-- creazione tabella disposizione videogioco
Create table disposizione_videogioco
(
ID_disp int not null auto_increment primary key,
titolo varchar(50) not null,
codicestore int not null,
settore int,
num_copie int,
foreign key (titolo) references videogioco(titolo),
foreign key (codicestore) references store(codicestore)
);

-- prova funzionamento tabella
select * from disposizione_videogioco;
-- popolamento tabella disposizione videogioco
-- show create table disposizione_videogioco;
-- select * from disposizione_videogioco;

-- cancellazione tabella disposizione videogioco.
-- drop table disposizione_videogioco;

-- popolamento tabella store.

Insert into store (Codicestore,IndirizzoFisico,NumeroTelefono) values (1,"Via Roma 123,Milano","+39021234567");
Insert into store (Codicestore,IndirizzoFisico,NumeroTelefono) values (2,"Corso Italia 456,Roma","+39067654321");
Insert into store (Codicestore,IndirizzoFisico,NumeroTelefono) values (3,"Piazza San Marco 789,Venezia","+390419876543");
Insert into store (Codicestore,IndirizzoFisico,NumeroTelefono) values (4,"Viale degli Ulivi 234, Napoli", "+390813456789");
Insert into store (Codicestore,IndirizzoFisico,NumeroTelefono) values (5,"Via Torino 567,Torino","+390118765432");
Insert into store (Codicestore,IndirizzoFisico,NumeroTelefono) values (6,"Corso Vittorio Emanuele 890, Firenze","+390552345678");
Insert into store (Codicestore,IndirizzoFisico,NumeroTelefono) values (7,"Piazza Duomo 123, Bologna","+390518765432");
Insert into store (Codicestore,IndirizzoFisico,NumeroTelefono) values (8,"Via Garibaldi 456, Genova","+390102345678");
Insert into store (Codicestore,IndirizzoFisico,NumeroTelefono) values (9,"Lungarno Mediceo 789, Pisa","+390508765432");
Insert into store (Codicestore,IndirizzoFisico,NumeroTelefono) values (10,"Corso Cavour 101, Palermo","+390912345678");

Alter table IMPIEGATO modify Nome varchar(255);

-- prova tabella store.
select * from store;

-- popolamente tabella impiegato.
Insert into impiegato (CodiceFiscale,Nome,TitoloStudio,Recapito) values ("ABC12345XYZ67890","Mario Rossi","Laurea in Economia","mario.rossi@email.com");
Insert into impiegato (CodiceFiscale,Nome,TitoloStudio,Recapito) values ("DEF67890XYZ12345","Anna Verdi","Diploma di Ragioneria","anna.verdi@email.com");
Insert into impiegato (CodiceFiscale,Nome,TitoloStudio,Recapito) values ("GHI12345XYZ67890","Luigi Bianchi","Laurea in Informatica","luigi.bianchi@email.com");
Insert into impiegato (CodiceFiscale,Nome,TitoloStudio,Recapito) values ("JKL67890XYZ12345","Laura Neri","Lauerea in Lingue","laura.neri@email.com");
Insert into impiegato (CodiceFiscale,Nome,TitoloStudio,Recapito) values ("MNO12345XYZ67890","Andrea Moretti","Diploma di Geometra","andrea.moretti@email.com");
Insert into impiegato (CodiceFiscale,Nome,TitoloStudio,Recapito) values ("PQR67890XYZ12345","Giulia Ferrara","Laurea in Psicologia","giulia.ferrara@email.com");
Insert into impiegato (CodiceFiscale,Nome,TitoloStudio,Recapito) values ("STU12345XYZ67890","Marco Esposito","Diploma di Elettronica","marco.esposito@email.com");

-- prova funzionamento tabella store.
SELECT 
    *
FROM
    store;
    
-- Popolamento tabella servizio impiegato.
Insert into servizio_impiegato (codiceFiscale,CodiceStore,Datainizio,DataFine,Carica) values ("ABC12345XYZ67890",1,2023-01-01,2023-12-31,"Cassiere");

-- prova funzionamento tabella servizio impiegato
SELECT 
    *
FROM
    servizio_impiegato;
    
-- popolamento tabella servizio impiegato
Insert into servizio_impiegato (codiceFiscale,CodiceStore,DataInizio,DataFine,Carica) values ("DEF67890XYZ12345",2,"2023-02-01","2023-11-30","Commesso");
insert INTO servizio_impiegato (codicefiscale,codicestore,datainizio,datafine,Carica) values ("GHI12345XYZ67890",3,"2023-03-01","2023-10-31","Magazziniere");
Insert Into servizio_impiegato (codicefiscale,codicestore,datainizio,datafine,carica) values ("JKL67890XYZ67890",4,"2023-04-01","2023-09-30","Addetto alle vendite");
Insert into servizio_impiegato (codicefiscale,codicestore,datainizio,datafine,carica) values ("MNO12345XYZ67890",5,"2023-05-01","2023-08-31","Addetto alle pulizie");
insert into servizio_impiegato (codicefiscale,codicestore,datainizio,datafine,carica) values ("PQR67890XYZ12345",6,"2023-06-01","2023-07-31","Commesso");
Insert into servizio_impiegato (codicefiscale,codicestore,datainizio,datafine,carica) values ("STU12345XYZ67890",7,"2023-07-01","2023-06-30","Commesso");
Insert into servizio_impiegato (codicefiscale,codicestore,datainizio,datafine,carica) values ("VWX67890XYZ12345",8,"2023-08-01","2023-05-31","Cassiere");
Insert into servizio_impiegato (codicefiscale,codicestore,datainizio,datafine,carica) values ("YZA12345XYZ67890",9,"2023-09-01","2023-04-30","Cassiere");
Insert into servizio_impiegato (codicefiscale,codicestore,datainizio,datafine,carica) values ("BCD67890XYZ12345",10,"2023-10-01","2023-03-31","Cassiere");

-- prova funzionamento servizio impiegato.
SELECT 
    *
FROM
    servizio_impiegato;
    
-- prova funzionamento tabella store.
    
SELECT 
    *
FROM
    store;
    
-- Prova funzionamento tabella impiegato.
    
SELECT 
    *
FROM
    impiegato;
    
-- prova funzionamento tabella servizio_impiegato.
    
SELECT 
    *
FROM
    servizio_impiegato;
    
-- Aggiunta colonna Remakedi in videogioco
Alter table videogioco add column RemakeDi varchar(255);

-- prova funzionamento tabella videogioco.
SELECT 
    *
FROM
    videogioco;
    
-- Popolamento tabella videogioco
Insert into videogioco (Titolo,sviluppatore,Annodistribuzione,CostoAcquisto,Genere,RemakeDi) values ("Fifa 2023","EA sports","2023-01-01",49.99,"calcio","null");
Insert into videogioco (titolo,sviluppatore,Annodistribuzione,CostoAcquisto,Genere,RemakeDi) values ("Assassin's Creed: Valhalla", "Ubisoft","2020-01-01",59.99,"Action","null");
Insert into videogioco (titolo,sviluppatore,Annodistribuzione,CostoAcquisto,Genere,RemakeDi) values ("Super Mario Odyssey","Nointendo","2017-01-01",39.99,"Platform","null");
Insert into videogioco (titolo,sviluppatore,annodistribuzione,costoacquisto,genere,remakedi) values ("The Last of us part II","Naughty Dog","2020-01-01",69.99,"Action","null");
Insert into videogioco (titolo,sviluppatore,annodistribuzione,costoacquisto,genere,remakedi) values ("Cyberpunk 2077","CD Projekt Red","2020-01-01",49.99,"RPG","null");
Insert into videogioco (titolo,sviluppatore,annodistribuzione,costoacquisto,genere,remakedi) values ("Animal Crossing:New Horizons","Nintendo","2020-01-01",54.99,"Simulation","null");
insert into videogioco (titolo,sviluppatore,annodistribuzione,costoacquisto,genere,remakedi) values ("Call of Duty: Warzone","Infinity Ward","2020-01-01",0.00,"FPS","null");
insert into videogioco (titolo,sviluppatore,annodistribuzione,costoacquisto,genere,remakedi) values ("The Legend of Zelda: Breath in the wild","Nintendo","2017-01-01",59.99,"Action-adventure","null");
insert into videogioco (titolo,sviluppatore,annodistribuzione,costoacquisto,genere,remakedi) values ("Fortnite","Epic Games","2017-01-01",0.00,"Battle Royale","null");
insert into videogioco (titolo,sviluppatore,annodistribuzione,costoacquisto,genere,remakedi) values ("Red Dead Redemption 2","Rockstar Games","2018-01-01",39.99,"Action-Adventure","null");

-- prova funzionamento tabella videogioco.

SELECT 
    *
FROM
    videogioco;

-- Creazione tabella collocazione videogioco.
CREATE TABLE CollocazioneVideogioco (
    Id_C INTEGER PRIMARY KEY NOT NULL AUTO_INCREMENT,
    CodiceStore INTEGER,
    Titolo VARCHAR(255),
    CONSTRAINT codicestore FOREIGN KEY (codicestore)
        REFERENCES store (codicestore),
    CONSTRAINT titolo FOREIGN KEY (titolo)
        REFERENCES videogioco (titolo)
);
alter table store modify codicestore integer primary key not null;  
alter table videogioco modify titolo varchar(255) primary key not null;
drop table collocazionevideogioco;
SELECT 
    *
FROM
    collocazionevideogioco;
    
-- Create table disposizione_videogioco
-- (
-- ID_disp int not null auto_increment primary key,
-- titolo varchar(50) not null,
-- codicestore int not null,
-- settore int,
-- num_copie int,
-- foreign key (titolo) references videogioco(titolo),
-- foreign key (codicestore) references store(codicestore)
-- );
drop table disposizione_videogioco;

-- creazione tabella collocazione videogioco;

CREATE TABLE CollocazioneVideogioco (
    Id_C INTEGER PRIMARY KEY NOT NULL AUTO_INCREMENT,
    CodiceStore INTEGER,
    Titolo VARCHAR(255),
    CONSTRAINT codicestore FOREIGN KEY (codicestore)
        REFERENCES store (codicestore),
    CONSTRAINT titolo FOREIGN KEY (titolo)
        REFERENCES videogioco (titolo)
	);
alter table collocazionevideogioco add column settore int;
alter table collocazionevideogioco add column num_copie int;

-- cancellazione tabella collocazione videogioco.

drop table collocazionevideogioco;

-- creazione tabella collocazione videogioco.

CREATE TABLE CollocazioneVideogioco 
	(
    Id_C INTEGER PRIMARY KEY NOT NULL AUTO_INCREMENT,
    CodiceStore INTEGER,
    Titolo VARCHAR(255),
    settore int,
    num_copie int,
    FOREIGN KEY (Codicestore)
        REFERENCES store (Codicestore),
	FOREIGN KEY (titolo)
        REFERENCES videogioco (titolo)
        );
drop table collocazionevideogioco;

-- crazione tabella CollocazioneVideogioco.

CREATE TABLE CollocazioneVideogioco 
	(
    Id_C INTEGER PRIMARY KEY NOT NULL AUTO_INCREMENT,
    CodiceStore INTEGER,
    Titolo VARCHAR(255),
    settore int,
    num_copie int,
    FOREIGN KEY (Codicestore)
        REFERENCES store (Codicestore),
	FOREIGN KEY (Titolo)
        REFERENCES VIDEOGIOCO (Titolo)
        );
drop table collocazionevideogioco;

CREATE TABLE CollocazioneVideogioco 
	(
    Id_C INTEGER PRIMARY KEY NOT NULL AUTO_INCREMENT,
    Codice_Store INTEGER,
    Titolo VARCHAR(255),
    settore int,
    num_copie int,
    FOREIGN KEY (Codice_store)
        REFERENCES store (Codicestore),
	FOREIGN KEY (Titolo)
        REFERENCES VIDEOGIOCO (Titolo)
        );

-- prova tabella
select * from collocazionevideogioco;

-- popolamento tabella collocazione videogioco.
insert into CollocazioneVideogioco (Codice_store,Titolo,settore,num_copie) values (1,"fifa 2023",1,37);
insert into Collocazionevideogioco (Codice_store,Titolo,settore,num_copie) values (2,"fifa 2023",1,10);
insert into CollocazioneVideogioco (Codice_store,titolo,settore,num_copie) values (3,"fifa 2023",1,4);
insert into CollocazioneVideogioco (codice_store,titolo,settore,num_copie) values (4,"fifa 2023",1,39);
insert into CollocazioneVideogioco (Codice_store,titolo,settore,num_copie) values (5,"Fifa 2023",1,24);
insert into CollocazioneVideogioco (codice_store,titolo,settore,num_copie) values (6,"Fifa 2023",1,14);
insert into Collocazionevideogioco (codice_store,titolo,settore,num_copie) values (7,"Fifa 2023",1,10);
insert into collocazionevideogioco (codice_store,titolo,settore,num_copie) values (8,"Fifa 2023",1,38);
insert into collocazionevideogioco (codice_store,titolo,settore,num_copie) values (9,"fifa 2023",1,27);
insert into collacazionevideogioco (codice_store,titolo,settore,num_copie) values (10,"fifa 2023",1,38);
insert into collocazionevideogioco (codice_store,titolo,settore,num_copie) values (2,"Assassin's creed: Valhalla",3,14);
insert into collocazionevideogioco (codice_store,titolo,settore,num_copie) values (10,"Assassin's creed: Valhalla",3,19);
insert into collocazionevideogioco (codice_store,titolo,settore,num_copie) values (1,"Assasssin's creed: Valhalla",3,31);
insert into collocazionevideogioco (codice_store,titolo,settore,num_copie) values (3,"Assassin's creed: Valhalla",3,33);
insert into collocazionevideogioco (codice_store,titolo,settore,num_copie) values (7,"Assassin's creed: Valhalla",3,39);
insert into collocazionevideogioco (codice_store,titolo,settore,num_copie) values (9,"Assassin's creed: Valhalla",3,14);
insert into collocazionevideogioco (codice_store,titolo,settore,num_copie) values (4,"Super Mario Odyssey",2,13);
insert into collocazionevideogioco (codice_store,titolo,settore,num_copie) values (7,"Super Mario Odyssey",2,19);
insert into collocazionevideogioco (codice_store,titolo,settore,num_copie) values (9,"Super Mario Odyssey",2,2);
insert into collocazionevideogioco (codice_store,titolo,settore,num_copie) values (1,"Super Mario Odyssey",2,1);
insert into collocazionevideogioco (codice_store,titolo,settore,num_copie) values (8,"Super Mario Odyssey",2,5);
insert into collocazionevideogioco (codice_store,titolo,settore,num_copie) values (3,"The Last of us part II",3,12);
insert into collocazionevideogioco (codice_store,titolo,settore,num_copie) values (7,"The Last of us part II",3,33);
insert into collocazionevideogioco (codice_store,titolo,settore,num_copie) values (9,"The Last of us part II",3,19);
insert into collocazionevideogioco (codice_store,titolo,settore,num_copie) values (5,"The Last of us part II",3,2);
Insert into collocazionevideogioco (codice_store,titolo,settore,num_copie) values (2,"The Last of us part II",3,1);
insert into collocazionevideogioco (codice_store,titolo,settore,num_copie) values (6,"CyberPunk 2077",4,28);
Insert into collocazionevideogioco (codice_store,titolo,settore,num_copie) values (8,"CyberPunk 2077",4,15);
insert into collocazionevideogioco (codice_store,titolo,settore,num_copie) values (5,"CyberPunk 2077",4,26);
insert into collocazionevideogioco (codice_store,titolo,settore,num_copie) values (9,"Animal Crossing:New Horizons",2,29);
Insert into collocazionevideogioco (codice_store,titolo,settore,num_copie) values (6,"Animal Crossing:New Horizons",2,40);
insert into collocazionevideogioco (codice_store,titolo,settore,num_copie) values (6,"Call of Duty: Warzone",4,38);
Insert into collocazionevideogioco (codice_store,titolo,settore,num_copie) values (4,"Call of Duty: Warzone",4,32);
Insert into collocazionevideogioco (codice_store,titolo,settore,num_copie) values (5,"Call of Duty: Warzone",4,38);
insert into collocazionevideogioco (codice_store,titolo,settore,num_copie) values (5,"The Legend Of Zelda: Breath in the wild",2,21);
insert into collocazionevideogioco (codice_store,titolo,settore,num_copie) values (8,"The Legend of Zelda: Breath in the wild",2,32);
Insert into collocazionevideogioco (codice_store,titolo,settore,num_copie) values (4,"The Legend of Zelda: Breath in the wild",2,34);
Insert into collocazionevideogioco (codice_store,titolo,settore,num_copie) values (4,"Fortnite",5,38);
Insert into collocazionevideogioco (codice_store,titolo,settore,num_copie) values (10,"Fortnite",5,33);
Insert into collocazionevideogioco (codice_store,titolo,settore,num_copie) values (3,"Fortnite",5,30);
Insert into collocazionevideogioco (codice_store,titolo,settore,num_copie) values (2,"Fortnite",5,37);
insert into collocazionevideogioco (codice_store,titolo,settore,num_copie) values (1,"Fortnite",5,5);
Insert into collocazionevideogioco (codice_store,titolo,settore,num_copie) values (8,"Red Dead Redemption 2",5,27);
insert into collocazionevideogioco (codice_store,titolo,settore,num_copie) values (3,"Red Dead Redemption 2",5,11);
insert into collocazionevideogioco (codice_store,titolo,settore,num_copie) values (7,"Red Dead Redemption 2",5,36);


-- inizio svolgimento es3

-- seleziona tutti gli impiegati con una laurea in economia

SELECT 
    *
FROM
    impiegato
WHERE
    titolostudio = 'Laurea in Economia';
    
/*
-- SELECT 
   -- *
-- FROM
   -- servizio_impiegato AS SI
      --  INNER JOIN
    -- impiegato AS I ON SI.carica
       -- OR I.titolostudio = 'Diploma di informatica';
  */
  
-- Seleziona gli impiegati con un titolo di studio diverso da "Laurea in Economia".

SELECT 
    *
FROM
    impiegato
WHERE
    titolostudio != 'Laurea in economia';
    
-- Seleziona i titoli di studio distinti tra gli impiegati.

SELECT 
    nome, titolostudio
FROM
    impiegato;
    
-- Seleziona i titoli e gli sviluppatori dei videogiochi distribuiti nel 2020.

SELECT 
    *
FROM
    videogioco
WHERE
    annodistribuzione = '2020-01-01';
    
-- Seleziona gli impiegati che lavorano come Cassiere o che hanno un Diploma di Informatica.

SELECT 
    *
FROM
    impiegato
        INNER JOIN
    servizio_impiegato ON impiegato.codicefiscale = servizio_impiegato.codicefiscale
WHERE
    carica = 'cassiere'
        OR titolostudio = 'Diploma di informatica';
        
-- Seleziona i nomi e i titoli degli impiegati che hanno iniziato a lavorare dopo il 1 gennaio 2023.

SELECT 
    impiegato.nome, impiegato.titolostudio
FROM
    impiegato
        INNER JOIN
    servizio_impiegato ON impiegato.codicefiscale = servizio_impiegato.codicefiscale
WHERE
    datainizio > '2023-01-01';

-- Seleziona gli impiegati che hanno iniziato a lavorare prima del 1 luglio 2023 e sono Commessi.

SELECT 
    *
FROM
    SERVIZIO_IMPIEGATO
WHERE
    CARICA = 'COMMESSO'
        AND DATAINIZIO < DATE('2023-07-01');
        
-- Seleziona i titoli dei videogiochi disponibili nei settori 1 o 3 del negozio 5.
SELECT 

*

FROM
	Collocazionevideogioco
WHERE
	CODICE_STORE=5
    AND SETTORE IN (1,3);
    
-- Seleziona i negozi con più di 20 copie disponibili di almeno un videogioco.

SELECT  DISTINCT

	CODICE_STORE

FROM
	Collocazionevideogioco
WHERE
	NUM_COPIE > 20
    ORDER BY CODICE_STORE;




